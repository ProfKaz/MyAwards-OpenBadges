Add your own badge PNGs here. Update config.json before running the generator.
